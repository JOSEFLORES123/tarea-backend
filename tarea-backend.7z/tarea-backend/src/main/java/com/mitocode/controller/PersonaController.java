package com.mitocode.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.mitocode.exception.ModeloNotFoundException;
import com.mitocode.model.Persona;
import com.mitocode.service.IPersonaService;

@RestController
@RequestMapping("/personas")
public class PersonaController {

	@Autowired
	private IPersonaService service;

	@GetMapping
	private ResponseEntity<List<Persona>> listar() throws Exception {
		List<Persona> lista = service.listar();
		return new ResponseEntity<List<Persona>>(lista, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Persona> listarPorID(@PathVariable("id") Integer id) throws Exception {
		Persona obj = service.listarPorID(id);
		if (obj == null) {
			throw new ModeloNotFoundException("ID no encontrado: " + id);
		}
		return new ResponseEntity<Persona>(obj, HttpStatus.OK);
	}

	@GetMapping("/hateoas/{id}")
	private EntityModel<Persona> listarPorIdHateoas(@PathVariable("id") Integer id) throws Exception {
		Persona obj = service.listarPorID(id);
		if (obj == null) {
			throw new ModeloNotFoundException("ID no encontrado: " + id);
		}
		EntityModel<Persona> recurso = EntityModel.of(obj);
		WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).listarPorID(id));

		recurso.add(link.withRel("persona-recurso"));
		return recurso;

	}

	@PostMapping
	private ResponseEntity<Void> registrar(@Valid @RequestBody Persona persona) throws Exception {

		Persona obj = service.registrar(persona);
		
		// localhost:8080/personas/5
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(obj.getIdPersona()).toUri();

		return ResponseEntity.created(location).build();

	}

	@PutMapping
	private ResponseEntity<Persona> modificar(@Valid @RequestBody Persona persona) throws Exception {

		Persona obj = service.modificar(persona);
		return new ResponseEntity<Persona>(obj, HttpStatus.OK);

	}

	@DeleteMapping("/{id}")
	private ResponseEntity<Void> eliminar(@PathVariable("id") Integer id) throws Exception {
		Persona obj = service.listarPorID(id);
		if (obj == null) {
			throw new ModeloNotFoundException("Id no encontrado: " + id);
		}

		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);

	}

}

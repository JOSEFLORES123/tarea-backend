package com.mitocode.repo;

import com.mitocode.model.Persona;

public interface IPersonaRepo extends IGenericRepo<Persona, Integer>{

}

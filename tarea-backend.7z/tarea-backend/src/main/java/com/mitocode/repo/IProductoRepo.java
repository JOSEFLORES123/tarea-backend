package com.mitocode.repo;

import com.mitocode.model.Producto;

public interface IProductoRepo extends IGenericRepo<Producto, Integer>{

}

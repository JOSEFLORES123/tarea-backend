package com.mitocode.repo;

import com.mitocode.model.Venta;

public interface IVentaRepo extends IGenericRepo<Venta, Integer> {

}

package com.mitocode.service;

import com.mitocode.model.Producto;

public interface IProductoService extends ICRUD<Producto,Integer> {

}
